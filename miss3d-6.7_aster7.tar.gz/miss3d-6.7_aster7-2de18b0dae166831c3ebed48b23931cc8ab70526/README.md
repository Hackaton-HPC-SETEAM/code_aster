# Miss3D

Ce dépôt contient les sources de Miss3D.

## Construction

Copier un des exemples de *Makefile* sous `src/Makefile.inc`.

Lancer la construction avec `make`

```bash
make -j $(nproc)
make prefix=INSTALLATION-PREFIX/miss3d-VERSION install
```

*Voir ci-dessous un exemple de construction dans le conteneur salome_meca.*

## Validation

Les tests peuvent exécutés directement en utilisant le script `run_miss3d_test`
tel que trouvé dans `$PATH`.

```bash
$ run_miss3d_test --help
usage: run_miss3d_test path/to/filename.in
   Execute MISS3D from an input file.

   MISS_TMPDIR environment variable can be defined to change the
   temporary directory (default: /tmp).
```

Exemple :

```bash
run_miss3d_test .../miss3d/test/fic1.001/fic1.001.in
```

Tous les fichiers présents dans le même dossier que le fichier `.in` sont
copiés dans un répertoire temporaire d'exécution (modifiable avec MISS_TMPDIR).

### Liste des tests de validation

```bash
$ cd test
$ ctest -N
  Test  #1: MISS3D_fic1.001_fic1.001.in
  Test  #2: MISS3D_fic1.002_fic1.002_modA.in
  Test  #3: MISS3D_fic1.002_fic1.002_modAbis.in
  Test  #4: MISS3D_fic1.002_fic1.002_modAter.in
  Test  #5: MISS3D_fic1.002_fic1.002_modB.in
  Test  #6: MISS3D_fic1.002_fic1.002_modBbis.in
  Test  #7: MISS3D_fic1.002_fic1.002_modBter.in
  Test  #8: MISS3D_fic1.007_fic1.007.in
  Test  #9: MISS3D_fic1.008_fic1.008.in
  Test #10: MISS3D_fic2.001_fic2.001.in
  Test #11: MISS3D_fic2.002_fic2.002.in
  Test #12: MISS3D_fic2.004_dplahom.in
  Test #13: MISS3D_fic2.004_dplastra.in
  Test #14: MISS3D_fic2.004_plahom.in
  Test #15: MISS3D_fic2.004_plastra.in
  Test #16: MISS3D_fic3.001_fic3.001.in

Total Tests: 16
```

### Lancement automatique des tests

Exécution d'un cas-test :

```bash
# charger l'environnement d'exécution si nécessaire
$ cd test
$ ctest -V -R MISS3D_fic1.002_fic1.002_modA.in
```

Exécution de tous les tests (exemple en lançant jusqu'à 12 tests simultanément) :

```bash
# charger l'environnement d'exécution si nécessaire
$ cd test
$ ctest -j 12
```

Remarque :
> Pour utiliser le parallélisme OpenMP, il suffit de définir la variable
> OMP_NUM_THREADS avant le lancement.

### Vérification des valeurs de non-régression des tests

De manière automatique, quand on exécute un test avec le script `run_miss3d_test`,
appelé quand on fait `ctest...`, le fichier Python `<nom-du-test>_post.py`
présent dans le répertoire du test permet de contrôler les valeurs obtenues vis
à vis de valeurs de référence.

Les valeurs de non-régression sont vérifiées par un script Python appelé
automatiquement par `run_miss3d_test` (donc aussi quand on fait `ctest ...`).
Ce script doit porté le même nom que le fichier `.in` + le suffixe `_post.py`.

Pour le test `fich1.002.in`, on vérifie les valeurs calculées avec
`fic1.002_modA_post.py` de ce type :

```python
from miss_testing import check_complex_values

check_complex_values(
    "imp_Z.modA", [(0.1, (3.0038 - 0.17856j)), (8.1, (1.9344 - 12.224j))]
)

check_complex_values(
    "imp_H.modA", [(0.1, (3.184 - 0.18974j)), (8.1, (3.1412 - 9.834j))]
)
...
```

Quand on lance le test en mode bavard (avec `ctest -V`), on obtient ce type
de sortie :

```none
2: Executing MISS3D...
2: working directory: /tmp/miss3d.tmp.lTo22BKdn6
2: input file: /home/G79848/dev/aster-prerequisites/miss3d/test/fic1.002/fic1.002_modA.in
2: executing Miss3d with fic1.002_modA.in...
2:  Number of threads:                     1
2:  MISS3D : MEMOIRE INITIALE=            500000000
2: executing fic1.002_modA_post.py...
2:  OK  imp_Z.modA ; para=0.1; value=3.0038
2:  OK  imp_Z.modA ; para=0.1; value=-0.17856
2:  OK  imp_Z.modA ; para=8.1; value=1.9344
2:  OK  imp_Z.modA ; para=8.1; value=-12.224
2:  OK  imp_H.modA ; para=0.1; value=3.184
2:  OK  imp_H.modA ; para=0.1; value=-0.18974
2:  OK  imp_H.modA ; para=8.1; value=3.1412
2:  OK  imp_H.modA ; para=8.1; value=-9.834
```

## Exemple de construction dans le conteneur de développement salome_meca

Pour simplifier les lignes de commandes, on définit un alias vers le script
de lancement du conteneur à utiliser :

```bash
alias ct=$HOME/containers/salome_meca-edf-2021.0.0-1-20210811-scibian-9
```

On exporte des variables que l'on pourra retrouver dans le conteneur :

```bash
# répertoire d'installation
export PREFIX=/local00/tmp/$USER/miss-install

# mode debug pour conserver les répertoires temporaires d'exécution des tests
export MISS_DEBUG=1
```

Création du `Makefile.inc` :

```bash
sed -e 's/LIBMATH/-lopenblas/g' -e 's/LIBOPENMP/-lgomp/g' \
    src/Makefile.inc.gnu64.template > src/Makefile.inc
```

Dans un shell du conteneur :

```bash
# se placer dans le conteneur
ct --shell

# construction et installation
make -j 12
make prefix=$PREFIX install

# pour avoir run_miss3d_test dans le PATH
export PATH=$PREFIX/bin:$PATH

# se placer dans le répertoire des tests (installation ou source)
cd $PREFIX/share/test
# ou
cd test

# lancement d'un test
ctest -V -R MISS3D_fic1.002_fic1.002_modA.in

# lancement de tous les tests 'fic1.002_modA' (par expression régulière)
# sans -V, en parallèle
ctest -R fic1.002_modA -j 4
```
