from miss_testing import check_complex_values


check_complex_values(
    "imp_Z.modBter", [(0.1, (5.2262 - 0.45062j)), (8.1, (5.5748 - 36.301j))]
)

check_complex_values(
    "imp_H.modBter", [(0.1, (6.8584 - 0.6592j)), (8.1, (5.0147 - 40.103j))]
)

check_complex_values(
    "imp_R.modBter", [(0.1, (4.3491 - 0.17919j)), (8.1, (1.7836 - 13.971j))]
)

check_complex_values(
    "imp_T.modBter", [(0.1, (4.1059 - 0.082596j)), (8.1, (3.0556 - 5.16j))]
)
