from miss_testing import check_complex_values


check_complex_values(
    "imp_Z.modAter", [(0.1, (3.243 - 0.18736j)), (8.1, (3.0824 - 11.354j))]
)

check_complex_values(
    "imp_H.modAter", [(0.1, (2.7873 - 0.14619j)), (8.1, (3.947 - 6.7462j))]
)

check_complex_values(
    "imp_R.modAter", [(0.1, (0.66457 - 0.014156j)), (8.1, (0.49083 - 0.77517j))]
)

check_complex_values(
    "imp_T.modAter", [(0.1, (0.89299 - 0.017891j)), (8.1, (0.85471 - 0.86213j))]
)
