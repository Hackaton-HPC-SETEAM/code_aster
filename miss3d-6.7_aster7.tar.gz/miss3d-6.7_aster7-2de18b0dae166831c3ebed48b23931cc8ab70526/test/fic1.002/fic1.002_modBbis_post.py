from miss_testing import check_complex_values


check_complex_values(
    "imp_Z.modBbis", [(0.1, (5.1667 + 0.29913j)), (8.1, (5.3201 - 35.734j))]
)

check_complex_values(
    "imp_H.modBbis", [(0.1, (6.369 + 0.010881j)), (8.1, (8.5897 - 37.253j))]
)

check_complex_values(
    "imp_R.modBbis", [(0.1, (4.3823 + 0.29491j)), (8.1, (3.1162 - 13.471j))]
)

check_complex_values(
    "imp_T.modBbis", [(0.1, (3.8849 + 0.24584j)), (8.1, (2.8739 - 6.0254j))]
)
