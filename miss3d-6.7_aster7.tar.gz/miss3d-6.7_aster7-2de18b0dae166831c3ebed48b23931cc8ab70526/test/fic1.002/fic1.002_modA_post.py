from miss_testing import check_complex_values


check_complex_values(
    "imp_Z.modA", [(0.1, (3.0038 - 0.17856j)), (8.1, (1.9344 - 12.224j))]
)

check_complex_values(
    "imp_H.modA", [(0.1, (3.184 - 0.18974j)), (8.1, (3.1412 - 9.834j))]
)

check_complex_values(
    "imp_R.modA", [(0.1, (0.58811 - 0.011957j)), (8.1, (0.29042 - 0.8306j))]
)

check_complex_values(
    "imp_T.modA", [(0.1, (1.1703 - 0.023459j)), (8.1, (0.83273 - 1.3407j))]
)
