from miss_testing import check_complex_values


check_complex_values(
    "imp_Z.modAbis", [(0.1, (2.9167 - 0.17812j)), (8.1, (1.7623 - 12.105j))]
)

check_complex_values(
    "imp_H.modAbis", [(0.1, (3.0667 - 0.18154j)), (8.1, (3.0573 - 9.745j))]
)

check_complex_values(
    "imp_R.modAbis", [(0.1, (0.56898 - 0.011998j)), (8.1, (0.27538 - 0.82298j))]
)

check_complex_values(
    "imp_T.modAbis", [(0.1, (1.0958 - 0.020997j)), (8.1, (0.71794 - 1.3014j))]
)
