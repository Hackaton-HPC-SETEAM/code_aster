    write(iout,4000) 'ACONTR'
    write(iout,1000)
    write(iout,4000) 'ADATA'
    write(iout,1000) &
    'PXNOD',PXNOD, &
    'PNODEL',PNODEL, &
    'PCHPLM',PCHPLM, &
    'PGROUP',PGROUP, &
    'PNODGR',PNODGR, &
    'PELTGR',PELTGR, &
    'PTRIN',PTRIN, &
    'PMASK',PMASK, &
    'PMODGR',PMODGR, &
    'PORDGR',PORDGR, &
    'PGRPCH',PGRPCH, &
    'PXCTR',PXCTR, &
    'ptymod',ptymod, &
    'plskbe',plskbe, &
    'piddl',piddl, &
    'piddlg',piddlg, &
    'piel',piel, &
    'pnchdf',pnchdf, &
    'pngrdf',pngrdf, &
    'pgrext',pgrext, &
    'pchext',pchext, &
    'pgrexd',pgrexd, &
    'pchexd',pchexd, &
    'ptypgr',ptypgr
    write(iout,4000) 'ADFRQ'
    write(iout,1000)
    write(iout,4000) 'ADMAIN'
    write(iout,1000) &
    'MTOT',MTOT, &
    'PLAST',PLAST, &
    'PDATA',PDATA, &
    'PRESOU',PRESOU, &
    'PCALUI',PCALUI, &
    'PGEOM',PGEOM, &
    'NGEOM',NGEOM, &
    'PCONTR',PCONTR, &
    'PPRPIN',PPRPIN, &
    'NPRPIN',NPRPIN, &
    'PDOS2M',PDOS2M, &
    'PMVFD',PMVFD, &
    'PTIME',PTIME, &
    'PRESAL',PRESAL, &
    'pdiff',pdiff, &
    'pnbui',pnbui, &
    'pexdos',pexdos, &
    'pfidom',pfidom, &
    'pprdos',pprdos, &
    'pt_max',pt_max
    write(iout,4000) 'amth'
    write(iout,1000)
    write(iout,4000) 'AGEOM'
    write(iout,1000) &
    'PXCDG',PXCDG, &
    'PCHLME',PCHLME, &
    'PCHBEM',PCHBEM, &
    'PAIRE',PAIRE, &
    'PNOREL',PNOREL, &
    'PXPGG',PXPGG, &
    'PNEPGG',PNEPGG, &
    'PWPGG',PWPGG, &
    'PELTGG',PELTGG, &
    'PXPGF',PXPGF, &
    'PNEPGF',PNEPGF, &
    'PWPGF',PWPGF, &
    'PELTGF',PELTGF, &
    'pgeo',pgeo, &
    'pexche',pexche, &
    'pmaire',pmaire, &
    'piddlc',piddlc, &
    'ityche',ityche, &
    'pxsloc',pxsloc
    write(iout,4000) 'DIMEL0'
    write(iout,1000)
    write(iout,4000) 'AMVFD'
    write(iout,1000)
    write(iout,4000) 'APRPIN'
    write(iout,1000)
    write(iout,4000) 'APRPUI'
    write(iout,1000) &
    'PORDUI',PORDUI, &
    'PNPUI',PNPUI, &
    'PWZSUI',PWZSUI, &
    'PZRCWV',PZRCWV
    write(iout,4000) 'ARESA'
    write(iout,1000)
    write(iout,4000) 'ARESO'
    write(iout,1000) &
    'PUGEF',PUGEF, &
    'PTGEF',PTGEF, &
    'PUGKRS',PUGKRS, &
    'PUGKEF',PUGKEF, &
    'PTGKEF',PTGKEF, &
    'PTG0',PTG0, &
    'PS2M',PS2M, &
    'PS2MUI',PS2MUI, &
    'PS2MBE',PS2MBE, &
    'PS1M',PS1M, &
    'PSOL',PSOL, &
    'Ptd0',Ptd0, &
    'Ptdbe',Ptdbe, &
    'PIMPDC',PIMPDC, &
    'PFSEQ',PFSEQ, &
    'PIMPBE',PIMPBE, &
    'PFSBE',PFSBE, &
    'PKGEN',PKGEN, &
    'PKGEBE',PKGEBE, &
    'PFSGEN',PFSGEN, &
    'PFSGBE',PFSGBE, &
    'PugefP',PugefP, &
    'PtgefP',PtgefP
    write(iout,4000) 'AREUI'
    write(iout,1000) &
    'PCHUIE',PCHUIE, &
    'PTRUIU',PTRUIU, &
    'PTRUIT',PTRUIT, &
    'PUGKUI',PUGKUI, &
    'PUGRSI',PUGRSI
