    INTEGER*8 :: ncle
    PARAMETER ( NCLE = 63 )
    CHARACTER*4 :: MOT(NCLE)
    DATA MOT /'LIRE','UI  ','TUI ','UD0 ','TUD0','UDM ','TUDM', &
    'UCTR','IMPD','FORC','KGEN','FSGE','MAIL','FINP', &
    'EOF ','FICH','MVFD','UTOT','TTOT','CTOT','KEXT', &
    'CUI ','USOL','TSOL','CSOL','TIME','FINT','SPEC', &
    'FILT','SMOD','FINS','FINM','SCUI','SCTR','SCTO', &
    'SSOL','IFSS','FTOT','MASS','RIGI','AMOR','RTOT', &
    'EIGE','EIGV','MEIG','TITR','STRA','DOSU','DOSS', &
    'DOFU','DOFS','DOFR','CELL','CEL2','PCUI','PCSO', &
    'PCTO','PSOL','PTOT','PCTR','PDM ','PUI ','PD0 '/

