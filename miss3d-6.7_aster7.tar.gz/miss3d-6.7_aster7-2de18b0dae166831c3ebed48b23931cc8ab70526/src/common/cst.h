! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
!LATEXBEGIN
!LATEX
!LATEX  Constantes utilisees dans MISS
!LATEX
!LATEXEND
! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC


!      AUTEUR : D. CLOUTEAU    LMSS/ECP
!        REVISION


! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
!LATEXBEGIN
!LATEX     CODE D ERREUR
!LATEX\begin{itemize}
!LATEX \item \label{ISTDOUT} ISTDOUT :
!LATEX \item \label{IOK} IOK : Pas d'erreur
!LATEX \item \label{IER} IER : erreur
!LATEX \item \label{IERR} IERR : erreur
!LATEX \item \label{INEW} INEW : nouvelle valeur
!LATEX \item \label{IOLD} IOLD : ancienne valeur
!LATEX\end{itemize}
!LATEXEND
    INTEGER*8 :: ISTDOUT,IOK,IER,IERR,INEW,IOLD

    PARAMETER (ISTDOUT = 1)
    PARAMETER (IOK = 0)
    PARAMETER (IER = 1)
    PARAMETER (IERR = 1)
    PARAMETER (INEW = 0)
    PARAMETER (IOLD = -1)
!LATEXBEGIN
!LATEX     CODES NTRAN, Fichiers sequentiels
!LATEX\begin{itemize}
!LATEX \item \label{IWRITE} IWRITE : ecriture
!LATEX \item \label{IREAD} IREAD : lecture
!LATEX \item \label{IREWD} IREWD : rembobinage
!LATEX \item \label{NSIZH} NSIZH : taille des entetes
!LATEX\end{itemize}
!LATEXEND
    INTEGER*8 :: IWRITE,IREAD,IREWD,NSIZH

    PARAMETER (IWRITE = 1)
    PARAMETER (IREAD = 2)
    PARAMETER (IREWD = 10)
    PARAMETER (NSIZH = 16)
!LATEXBEGIN
!LATEX     TYPE DE FICHIER
!LATEX\begin{itemize}
!LATEX \item \label{ITCHP} ITCHP : Fichier de champs
!LATEX \item \label{ITIMP} ITIMP : Fichier d'impedance
!LATEX \item \label{ITFRC} ITFRC : Fichier de forces equivalentes
!LATEX \item \label{ITPRT} ITPRT : Fichier de stockage des parametres fonction de Green
!LATEX \item \label{ITCHPC} ITCHPC : Fichier de champs aux points de controle
!LATEX \item \label{ITUG} ITUG : Fichier stockage fonction de Green
!LATEX \item \label{ITFBA} ITFBA : Fichier matrice bande reelle
!LATEX \item \label{ITFBAC} ITFBAC :  Fichier matrice bande complexe
!LATEX \item \label{ITNDA} ITNDA : Fichier sequentiel
!LATEX \item \label{ITDOSF} ITDOSF : Fichier DOS2M en frequence
!LATEX \item \label{ITDOSS} ITDOSS : Fichier DOS2M en spectral
!LATEX \item \label{ITCOEF} ITCOEF : VARIABLES ALEATOIRES
!LATEX\end{itemize}
!LATEXEND
    INTEGER*8 :: ITCHP,ITIMP,ITFRC,ITPRT,ITCHPC,ITUG, &
    ITFBA,ITFBAC,ITNDA,ITDOSF,ITDOSS,itdev,ITCOEF

    PARAMETER (ITCHP  = 1)
    parameter (itdev  = 1)
    PARAMETER (ITIMP  = 2)
    PARAMETER (ITFRC  = 3)
    PARAMETER (ITPRT  = 4)
    PARAMETER (ITCHPC = 5)
    PARAMETER (ITUG   = 6)
    PARAMETER (ITFBA  = 7)
    PARAMETER (ITFBAC = 8)
    PARAMETER (ITNDA  = 9)
    PARAMETER (ITDOSF  = 10)
    PARAMETER (ITDOSS  = 11)
    PARAMETER (ITCOEF  = 12)
!LATEXBEGIN
!LATEX\begin{itemize}
!LATEX \item \label{MXFTY} MXFTY :  NOMBRE MAXIMUM DE TYPE DIFFERENT
!LATEX \item \label{MXLOOP} MXLOOP :  NOMBRE MAXIMUM DE BOUCLE DANS UN FICHIER
!LATEX \item \label{NDDLIM} NDDLIM :  NOMBRE MAXIMUM de DDL meca+hydrau
!LATEX\end{itemize}
!LATEXEND

    INTEGER*8 :: MXFTY,MXLOOP,NDDLIM

    PARAMETER (MXFTY  = 9)
    PARAMETER (MXLOOP  = 6)
    PARAMETER ( NDDLIM = 4 )


!LATEXBEGIN
!LATEX
!LATEX     IDENTIFICATEUR DE TYPE DE MODULE
!LATEX\begin{itemize}
!LATEX \item \label{IDCHUI} IDCHUI :  Champ incident
!LATEX \item \label{IDRESO} IDRESO :  Solveur BEM
!LATEX \item \label{IDCONT} IDCONT :  Representation BEM
!LATEX \item \label{IDPOST} IDPOST :  Postraitement
!LATEX \item \label{IDMVFD} IDMVFD :  Mouvement sismique induit
!LATEX \item \label{IDRESA} IDRESA :  Resolution multi-domaine
!LATEX \item \label{IDASDI} IDASDI :  Synthese multi-domaine
!LATEX\end{itemize}
!LATEXEND

    INTEGER*8 :: IDCHUI,IDRESO,IDCONT,IDPOST,IDMVFD,IDRESA,IDASDI

    PARAMETER ( IDCHUI = 1 )
    PARAMETER ( IDRESO = 2 )
    PARAMETER ( IDCONT = 3 )
    PARAMETER ( IDPOST = 4 )
    PARAMETER ( IDMVFD = 5 )
    PARAMETER ( IDRESA = 6 )
    PARAMETER ( IDASDI = 7 )

!LATEXBEGIN
!LATEX
!LATEX     TYPE DE GROUPE
!LATEX\begin{itemize}
!LATEX \item \label{ISURF} ISURF :  Surface
!LATEX \item \label{IVOL} IVOL :  Volume
!LATEX \item \label{IVIRT} IVIRT :  Virtuel
!LATEX \item \label{IPNT} IPNT :  Point
!LATEX \item \label{IPLAQ} IPLAQ :  Coque (surface double)
!LATEX \item \label{ITUBC} ITUBC :  tube section circulaire
!LATEX \item \label{ITUBR} ITUBR :  tube section rectangulaire
!LATEX \item \label{NBCAR} NBCAR :  nombre de carateristiques geometriques du groupe
!LATEX \item \label{NBGEO} NBGEO :  nombre de carateristiques geometriques des elements
!LATEX\end{itemize}
!LATEXEND

    INTEGER*8 :: ISURF,IVOL,IVIRT,IPLAQ,ITUBC,ITUBR,NBCAR,NBGEO,IPNT

    PARAMETER ( ISURF =  0 )
    PARAMETER ( IVOL  =  1 )
    PARAMETER ( IVIRT =  2 )
    PARAMETER ( IPLAQ =  3 )
    PARAMETER ( ITUBC =  4 )
    PARAMETER ( ITUBR =  5 )
    parameter ( ipnt  =  6 )

    PARAMETER ( NBCAR = 5)
    PARAMETER ( NBGEO = 3)

!LATEXBEGIN
!LATEX
!LATEX     CONDITIONS AUX LIMITES
!LATEX
!LATEX\begin{itemize}
!LATEX \item \label{NODEF} NODEF :  Non defini
!LATEX \item \label{IDEPL} IDEPL :  Deplacement impose
!LATEX \item \label{IDEPPR} IDEPPR :  Deplacement normal impose
!LATEX \item \label{IDEPRN} IDEPRN :  Deplacement normal impose (normale inversee)
!LATEX \item \label{IDEPA} IDEPA :  souplesse imposee
!LATEX \item \label{IDEPAN} IDEPAN :  souplesse imposee (normale inversee)
!LATEX \item \label{ISIG} ISIG :  Contraintes imposees
!LATEX \item \label{ISIGN} ISIGN :  Contraintes imposees (normale inversee)
!LATEX \item \label{IPRES} IPRES : Pression imposee
!LATEX \item \label{ISIGA} ISIGA :  Impedance imposee
!LATEX \item \label{ISIGAN} ISIGAN :  Impedance imposee (normale inversee)
!LATEX \item \label{IKFLU} IKFLU :  Impedance fluide imposee
!LATEX\end{itemize}
!LATEXEND

    INTEGER*8 :: NODEF,INDEF,IDEPL,IDEPPR,IDEPRN,ISIG ,ISIGN, &
    IDEPA,ISIGA,IDEPAN,ISIGAN,IPRES,IKFLU

    PARAMETER ( NODEF =  0 )
    PARAMETER ( IDEPL = -1 )
    PARAMETER ( IDEPPR= -2 )
    PARAMETER ( IDEPRN= -3 )
    PARAMETER ( IDEPA = -4 )
    PARAMETER ( IDEPAN= -5 )
    PARAMETER ( Ikflu= -6 )
    PARAMETER ( ISIG  =  1 )
    PARAMETER ( ISIGN =  6 )
    PARAMETER ( IPRES =  2 )
    PARAMETER ( ISIGA =  4 )
    PARAMETER ( ISIGAN=  5 )


!LATEXBEGIN
!LATEX
!LATEX     TYPE DE MODES
!LATEX
!LATEX\begin{itemize}
!LATEX \item \label{IDEF} IDEF :  Modes definis manuellement
!LATEX \item \label{IFEM} IFEM :  Modes elementaires aux noeuds
!LATEX \item \label{IBEM} IBEM :  Modes elementaires par elements
!LATEX \item \label{INOCH} INOCH :  Pas de champs impose (stochastique)
!LATEX\end{itemize}
!LATEXEND

    INTEGER*8 :: IDEF,IFEM,IBEM,INOCH
    PARAMETER ( IDEF =  0 )
    PARAMETER ( IFEM =  1 )
    PARAMETER ( IBEM =  2 )
    PARAMETER ( INOCH =  3 )


!LATEXBEGIN
!LATEX
!LATEX     TYPE DE DOMAINE
!LATEX
!LATEX\begin{itemize}
!LATEX \item \label{INDEF} INDEF : Non defini
!LATEX \item \label{IFLUI} IFLUI : espace fluide compressible
!LATEX \item \label{ISOL} ISOL : espace solide elastique homogene
!LATEX \item \label{ISTRA} ISTRA : solide elastique stratifie
!LATEX \item \label{IDFLU} IDFLU : demi-espace fluide compressible
!LATEX \item \label{BIPHA} BIPHA : biphasique (non dev.)
!LATEX \item \label{IDFLIC} IDFLIC : demi-espace fluide incompressible
!LATEX \item \label{IFLIC} IFLIC : espace fluide incompressible
!LATEX \item \label{IEXT} IEXT : exterieur (impedance donnee)
!LATEX \item \label{ISSH} ISSH : espace solide elastique homogene anti-plan (2D)
!LATEX \item \label{IKCM} IKCM : exterieur (masse rigidite amortissement donnes)
!LATEX \item \label{IKCMM} IKCMM : exterieur (masse rigidite amortissement donnees en fonction du mode)
!LATEX \item \label{ICHAR} ICHAR : chargement imposes ( force equivalente)
!LATEX \item \label{IRIG} IRIG : exterieur (rigidite donnee)
!LATEX \item \label{IAMO} IAMO : exterieur ( amortissement donnes)
!LATEX \item \label{IMAS} IMAS : exterieur (masse donnes)
!LATEX \item \label{IKC} IKC : exterieur (rigidite amortissement donnes)
!LATEX \item \label{IKM} IKM : exterieur (masse rigidite donnes)
!LATEX \item \label{ICM} ICM : exterieur (rigidite amortissement donnes)
!LATEX \item \label{IVID} IVID : exterieur vide (impedance=0=forces)
!LATEX \item \label{IMISS} IMISS : domaine composite MISS
!LATEX\end{itemize}
!LATEXEND

    INTEGER*8 :: IFLUI,ISOL ,ISTRA,IDFLU,BIPHA,IDFLIC,IFLIC,IEXT
    INTEGER*8 :: ICOQ,ICOB,ISSH
    INTEGER*8 :: IKCM,IRIG,IAMO,IMAS,IKC,IKM,ICM,IVID,IMISS,ikcmm
    INTEGER*8 :: ICHAR,ixfem

    PARAMETER ( INDEF = 0 )
    PARAMETER ( IFLUI = 1 )
    PARAMETER ( ISOL  = 3 )
    PARAMETER ( ISTRA = 2 )
    PARAMETER ( IDFLU = 4 )
    PARAMETER ( BIPHA = 5 )
    PARAMETER ( IDFLIC = 6 )
    PARAMETER ( IFLIC = 7 )
    PARAMETER ( IEXT = 8 )
    PARAMETER ( ICOQ = 9 )
    PARAMETER ( ICOB = 10 )
    PARAMETER ( ISSH = 11 )
    PARAMETER ( IKCM = 12 )
    PARAMETER ( ICHAR= 13 )
    PARAMETER ( IRIG = 14 )
    PARAMETER ( IAMO = 15 )
    PARAMETER ( IMAS = 16 )
    PARAMETER ( IKC  = 17 )
    PARAMETER ( IKM  = 18 )
    PARAMETER ( ICM  = 19 )
    PARAMETER ( IVID  = 20 )
    PARAMETER ( IMISS  = 21 )
    PARAMETER ( IKCMM  = 22 )
    PARAMETER ( IXFEM  = 23 )

!LATEXBEGIN
!LATEX
!LATEX     TYPES DE SYMETRIES
!LATEX
!LATEX\begin{itemize}
!LATEX \item \label{NOSYM} NOSYM : pas de symetries
!LATEX \item \label{IPERIO} IPERIO : periodicite 1d
!LATEX \item \label{IPERIC} IPERIC : periodicite avec modes corriges par $e^{ik\tilde{y}}$
!LATEX\end{itemize}
!LATEXEND

    INTEGER*8 :: NOSYM,IPERIO,IPERIC

    PARAMETER ( NOSYM = 0 )
    PARAMETER ( IPERIO = 1 )
    PARAMETER ( IPERIC = 2 )

!LATEXBEGIN
!LATEX
!LATEX     Ordre du spectre
!LATEX
!LATEX\begin{itemize}
!LATEX \item \label{ISACC} ISACC : spectre d'acceleration
!LATEX \item \label{ISVIT} ISVIT : spectre de vitesse
!LATEX \item \label{ISDEP} ISDEP : spectre de deplacements
!LATEX\end{itemize}
!LATEXEND

    INTEGER*8 :: ISACC,ISVIT,ISDEP
    PARAMETER ( ISACC = 1 )
    PARAMETER ( ISVIT  = 2 )
    PARAMETER ( ISDEP = 3 )

!LATEXBEGIN
!LATEX
!LATEX     Type de spectre
!LATEX
!LATEX\begin{itemize}
!LATEX \item  \label{ITABUL} ITABUL   : Fonction tabulee
!LATEX \item  \label{IRICKR} IRICKR   : Signal de Ricker
!LATEX \item  \label{ISINUS} ISINUS   : 1/2 sinisoide
!LATEX \item  \label{IHEAVI} IHEAVI   : Heaviside
!LATEX \item  \label{IDIRAC} IDIRAC   : Dirac
!LATEX\end{itemize}
!LATEXEND
    INTEGER*8 :: ITABUL,IRICKR,ISINUS,IHEAVI,IDIRAC
    PARAMETER ( ITABUL = 0 )
    PARAMETER ( IRICKR = 1 )
    PARAMETER ( ISINUS = 2 )
    PARAMETER ( IHEAVI = 3 )
    PARAMETER ( IDIRAC = 4 )

!LATEXBEGIN
!LATEX
!LATEX     TYPE D'operation sur les filtres
!LATEX
!LATEX\begin{itemize}
!LATEX \item \label{IMULT} IMULT : multiplication par le filtre
!LATEX \item \label{IDIVI} IDIVI : division par le filtre
!LATEX\end{itemize}
!LATEXEND

    INTEGER*8 :: IMULT,IDIVI
    PARAMETER ( IMULT = 1 )
    PARAMETER ( IDIVI = 2 )

!LATEXBEGIN
!LATEX
!LATEX     MODES DE FOURIER
!LATEX
!LATEX\begin{itemize}
!LATEX \item \label{MODE0} MODE0 : mode 0
!LATEX \item \label{MODE1} MODE1 : mode 1
!LATEX \item \label{NOAXI} NOAXI : pas d'axisymetrie
!LATEX\end{itemize}
!LATEXEND

    INTEGER*8 :: MODE0,MODE1,NOAXI
    PARAMETER ( MODE0 = 0 )
    PARAMETER ( MODE1 = 1 )
    PARAMETER ( NOAXI = -1 )

!     TYPES DE LISTE
!     ----------------

    INTEGER*8 :: irg0,irgn0,inrg0,inrgn0
    PARAMETER ( IRG0 = 0 )
    PARAMETER ( IRGN0 = 1 )
    PARAMETER ( INRG0 = 2 )
    PARAMETER ( INRGN0 = 3 )

!LATEXBEGIN
!LATEX
!LATEX     TYPES DE matrice
!LATEX
!LATEX\begin{itemize}
!LATEX \item \label{MATSTD} MATSTD : matrice pleine
!LATEX \item \label{MATID} MATID : identite a(1,1)=1 pour matrice rectangulaire
!LATEX \item \label{MATIDD} MATID2 : identite a(n,m)=1 pour matrice rectangulaire
!LATEX \item \label{MATINJ} MATINJ : matrice d'injection (adressage indirecte)
!LATEX \item \label{MATDIA} MATDIA : matrice diagonale
!LATEX \item \label{MATSKY} MATSKY : matrice skyline (non dev, voir matba2)
!LATEX \item \label{MATMOR} MATMOR : matrice morse (non dev)
!LATEX \item \label{MATBAN} MATBAN : matrice bande = matrice pleine + indice min et max de chaque colonne, obsolete voir MATBA2
!LATEX \item \label{MATCST} MATcst : MATID * constante
!LATEX \item \label{MATNUL} MATNUL : matrice nulle
!LATEX \item \label{MATBA2} MATBA2 : matrice bande = matrice stockee entre les indices min et max de chaque colonne,
!LATEX \item \label{MIMCMX} MIMCMX : taille max du tableau pour stocker les indices de MATBA2
!LATEX \item \label{MATCOMP} MATCOMP : matrice decomposee et geree comme 2 matrices. Chaque sous matrice est d un type precedent (normalement MATSTD ou MATID)--> utilise pour les interfaces volumiques et les fondations superficielles
!LATEX \item \label{MATMID} MATMID : matrice identit� et de signe negatif
!LATEX \item \label{MATMIDD} MATMI2 : matrice MATID2 de signe negatif
!LATEX \item \label{MATMST} MATMST : matrice standard de signe oppos� a la matrice stock�e
!LATEX\end{itemize}
!LATEXEND

    INTEGER*8 :: MATSTD,MATID,MATID2,MATINJ,MATDIA,MATSKY,MATCOMP, &
    MATMOR,matban,matcst,MATNUL,MATBA2,MIMCMX,MATMID,MATMDI, &
    MATMI2,MATMST,MATCT2,MATMCT,MATMC2

! RC 03/06/2004
! ajout de la matrice matct2
! ajout des matrices oppos�es � matid, matdia,matid2,matmst,matcst,matct2
! changement de la valeur de matcomp
! changement de la valeur de matnul

    PARAMETER (MATSTD=1)
    PARAMETER (MATID=2)
    PARAMETER (MATID2=21)
    PARAMETER (MATINJ=3)
    PARAMETER (MATDIA=4)
    PARAMETER (MATSKY=5)
    PARAMETER (MATMOR=6)
    PARAMETER (MATBAN=7)
    PARAMETER (MATCST=8)
!      PARAMETER (MATNUL=9)
    PARAMETER (MATNUL=0)
    PARAMETER (MATBA2=10)
!      PARAMETER (MATCOMP=-2)
    PARAMETER (MATCOMP=30)
    PARAMETER (MIMCMX=3)

    PARAMETER (MATCT2=9)

    PARAMETER (MATMID=-2)
    PARAMETER (MATMI2=-21)
    PARAMETER (MATMDI=-4)
    PARAMETER (MATMST=-1)
    PARAMETER (MATMCT=-8)
    PARAMETER (MATMC2=-9)

    INTEGER*8 :: sp1mat,sp2mat,st1mat,st2mat,sn1mat,sn2mat
    parameter( sp1mat=0,sp2mat=mimcmx,st1mat=1,st2mat=mimcmx+1, &
    sn1mat=2,sn2mat=mimcmx+2)


!LATEXBEGIN
!LATEX     Parametres machine
!LATEX
!LATEX      Configuration de la machine
!LATEX
!LATEX\begin{itemize}
!LATEX \item \label{LREG} LREG :  longueur des registres vectoriels
!LATEX \item \label{NPRO} NPRO :  nombre de processeurs utilises
!LATEX \item \label{NPROMX} NPROMX :  nombre maximum de processeurs
!LATEX \item \label{LMOT} LMOT :  nombre de mots memoire pour un reel S.P.
!LATEX\end{itemize}
!LATEXEND

    INTEGER*8 :: LREG,NPRO,LMOT
    INTEGER*8 :: NPROMX

    PARAMETER ( LREG =  100 )
!      PARAMETER ( NPROMX =   1024 )
    PARAMETER ( NPROMX =   64 )
    PARAMETER ( LMOT =   4 )

!LATEXBEGIN
!LATEX
!LATEX      Longueurs des mots
!LATEX
!LATEX\begin{itemize}
!LATEX \item \label{INTCT} INTCT :  entier 16 bits
!LATEX \item \label{INTLG} INTLG :  entier 32 bits
!LATEX \item \label{REALSP} REALSP :  reel 32 bits
!LATEX \item \label{REALDP} REALDP :  reel 64 bits
!LATEX \item \label{CPLXSP} CPLXSP :  complexe 64 bits
!LATEX \item \label{CPLXDP} CPLXDP :  complexe 128 bits
!LATEX \item \label{LCMPLX} LCMPLX :  NOMBRE DE REELs DANS UN COMPLEXE = 2
!LATEX\end{itemize}
!LATEXEND

    INTEGER*8 :: INTCT,INTLG,REALSP,REALDP,CPLXSP,CPLXDP,LCMPLX, &
    lg4,lg8,lg20,lg24,lg80

    PARAMETER ( INTCT=   1 )
    PARAMETER ( INTLG=   1 )
    PARAMETER (REALSP=   1 )
    PARAMETER (REALDP=   1 )
    PARAMETER (CPLXSP=   2 )
    PARAMETER (CPLXDP=   2 )
    PARAMETER (LCMPLX=   2 )
    PARAMETER (LG4   =   1 )
    PARAMETER (LG8   =   1 )
    PARAMETER (LG20  =   3 )
    PARAMETER (LG24  =   3 )
    PARAMETER (LG80  =   10 )

!LATEXBEGIN
!LATEX\begin{itemize}
!LATEX \item \label{NDIM} NDIM : Nombre de dimensions de l'espace geometrique
!LATEX \item \label{NBDDL} NBDDL : Nombre de ddl par point
!LATEX \item \label{NDDLI} NDDLI : nombre de ddl par point pour les champs VCHML
!LATEX \item \label{NBDDLM} NBDDLM : Nombre de ddl mecanique par point
!LATEX \item \label{NBDDLH} NBDDLH : Nombre de ddl hydrauliques par point
!LATEX \item \label{NBPHA} NBPHA : = NBDDL
!LATEX\end{itemize}
!LATEXEND

    INTEGER*8 :: NDIM,NBDDL,NDDLI,NBDDLM,NBDDLH,NBPHA
    COMMON /CONST/ NDIM,NBDDL,NDDLI,NBDDLM,NBDDLH,NBPHA,NPRO

    INTEGER*8 :: NOVMX
    PARAMETER (NOVMX=20)

    INTEGER*8 ::   itab,iexpr,iexpc,itriag,iwien,itruwh,igauss,iexpmd, &
    ikarma,ifract,ispher

!     TYPES DE FONCTION DE CORRELATION
!     --------------------------------
    parameter (itab   = 0)
    parameter (iexpr  = 1)
    parameter (iexpc  = 2)
    parameter (itriag = 3)
    parameter (iwien  = 4)
    parameter (itruwh = 5)
    parameter (igauss = 6)
    parameter (iexpmd = 7)
    parameter (ikarma = 8)
    parameter (ifract = 9)
    parameter (ispher =10)


    INTEGER*8 ::   iunif,igadev,imodev,ilatin,ilati2
    INTEGER*8 ::   koptx
    parameter (koptx = 50)

!     TYPES DE LOI DE PROBABILITE
!     ---------------------------
    parameter (iunif  = 0)
    parameter (igadev = 1)
    parameter (imodev = 2)
    parameter (ilatin = 3)
    parameter (ilati2 = 4)

! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC

            
