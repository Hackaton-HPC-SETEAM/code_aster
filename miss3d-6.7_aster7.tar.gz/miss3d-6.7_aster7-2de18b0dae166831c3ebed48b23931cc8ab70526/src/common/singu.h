    COMPLEX*16 VGKRSL(5)
    COMMON /singu/ vgkrsl
