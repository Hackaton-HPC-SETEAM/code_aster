
!    Mot cles du menu data

    INTEGER*8 :: ncle
    PARAMETER (NCLE=40)
    CHARACTER*4 ::  MOTCLE
    CHARACTER*4 ::  MOT(NCLE)
    DATA MOT /'TITR','MAIL','NOEU','ELEM','MATE','FREQ','CHAM','CONT', &
    'INTE','VERI','SAVE','SDOM','FLUI','STRA','DFLU','FINS', &
    'FIND','INCO','DINC','EXTE','KHRY','KHRX','COQE','NCON', &
    'COBE','MSOU','MTSH','SH'  ,'MODE','DOMA','KCM ','GROU', &
    'IMGO','VIDE','PERY','DOS2','MVOL','EVOL','MI3D','XFEM'/
