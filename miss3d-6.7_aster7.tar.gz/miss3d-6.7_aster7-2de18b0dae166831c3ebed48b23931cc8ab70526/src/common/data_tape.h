    INTEGER*8 :: NBLOOP(MXFTY)
    CHARACTER*4 :: MOTPST(MXLOOP,MXFTY)
    DATA NBLOOP /5,4,4,4,5,6,5,5,0/
    DATA MOTPST /'DDL ','ELEM','CHAM','MODE','FREQ','    ', &
    'CHPU','CHPT','MODE','FREQ','    ','    ', &
    'TUDM','UI  ','MODE','FREQ','    ','    ', &
    'TUDM','UI  ','MODE','FREQ','    ','    ', &
    'DDL ','POIN','CHAM','MODE','FREQ','    ', &
    'DDLF','SOUR','DDLR','ELEM','MODE','FREQ', &
    'DDL ','ELEM','CHAM','MODE','FREQ','    ', &
    'DDL ','POIN','CHAM','MODE','FREQ','    ', &
    '    ','    ','    ','    ','    ','    '/
