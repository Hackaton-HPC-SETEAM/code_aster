!M  COMMON MAIL
!LATEXBEGIN
!LATEX variables liees a la definition du maillage
!LATEX\begin{itemize}
!LATEX \item \label{NODTOT} NODTOT :  INTEGER*8 nombre de noeuds (INPUT)
!LATEX \item \label{NELTOT} NELTOT :  INTEGER*8 nombre d elements d un domaine
!LATEX \item \label{NELTSF} NELTSF :  INTEGER*8 nombre d elements a normale non nulle
!LATEX \item \label{NELEM} NELEM :  INTEGER*8 nombre d elements du maillage
!LATEX \item \label{MXNDEL} MXNDEL :  INTEGER*8 nombre maximum de noeuds des elements  CST
!LATEX \item \label{NCHTOT} NCHTOT :  INTEGER*8 nombre de champs imposes differents des champs
!LATEX                   UDO et BEM sur un domaine (INPUT)
!LATEX \item \label{NCHTG} NCHTG :  INTEGER*8 nombre de champs imposes differents des champs
!LATEX                   UDO et BEM sur tout le maillage (INPUT)
!LATEX \item \label{NELDIM} NELDIM :  INTEGER*8 NELTOT*NDIM  (AD....)
!LATEX \item \label{NGRP} NGRP :  INTEGER*8 nombre de groupe d elements ( INPUT/IELEMG )
!LATEX \item \label{NCH} NCH :  INTEGER*8 nombre de champs imposes ( RESOU/ADRESO )
!LATEX \item \label{NCHG} NCHG :  INTEGER*8 nombre de champs imposes globaux ( RESOU/ADRESO )
!LATEX \item \label{NPTCTR} NPTCTR :  INTEGER*8 nombre de points de controle hors de la surface
!LATEX                   ( INPUT )
!LATEX \item \label{NCHBEM} NCHBEM :  INTEGER*8 nombre de champs constants par elements imposes
!LATEX                   sur un domaine ( INPUT/LECCHP/NBBEM )
!LATEX \item \label{NCHBEG} NCHBEG :  INTEGER*8 nombre de champs constants par elements imposes
!LATEX                   sur le maillage ( INPUT/LECCHP/NBBEM )
! LATEX \item \label{NCHUI} NCHUI :  INTEGER*8 nombre de champs incident imposes
!LATEX \item \label{NCHUIG} NCHUIG :  INTEGER*8 nombre de champs incident imposes globaux
!LATEX \item \label{NCHSUI} NCHSUI :  INTEGER*8 nombre de champs imposes hormi les champs ud0 (ADRESO)
!LATEX \item \label{NDEFCH} NDEFCH :  INTEGER*8 nomdre de type de champs definis
!LATEX                   est limite a 2*ngrp
!LATEX \item \label{NCHGEX} NCHGEX :  INTEGER*8 nombre de modes imposes exterieurs
!LATEX \item \label{NCHGIN} NCHGIN :  INTEGER*8 nombre de modes imposes interieurs
!LATEX \item \label{IDOMG} IDOMG :  INTEGER*8 numero du domaine global courant
!LATEX \item \label{NSDOM} NSDOM :  nombre de sous-domaine pour le domaine courant different
!LATEX               de idomg
!LATEX \item \label{ITYMAT} ITYMAT : type du mat�riau,
!LATEX \item \label{NGRPG} NGRPG : nombre de groupes du domaine global,
!LATEX \item \label{ISDOM} ISDOM : num�ro du domaine courant,
!LATEX \item \label{NDOMN} NDOMN : nombre de domaines,
!LATEX \item \label{MXCH} MXCH : nombre max. de champs impos�s,
!LATEX \item \label{MXUI} MXUI : nombre max. de chargement,
!LATEX \item \label{NCHEXT} NCHEXT : nombre de champ ext�rieurs,
!LATEX \item \label{NCHINT} NCHINT : nombre de champs int�rieurs,
!LATEX \item \label{NDDLOC} NDDLOC : nombre de degr�s de libert� locaux,
!LATEX \item \label{N0DDL} N0DDL : num�ro du ddl � partir duquel la numerotation
!LATEX standart et l'assemblage du systeme different,
!LATEX\end{itemize}
!LATEXEND



    INTEGER*8 :: NODTOT,NELTOT,MXNDEL,NCHTOT,NELDIM,NGRP,NCH, &
    NPTCTR,NCHBEM,NCHUI,NCHSUI,NELEM,NCHTG,NCHBEG, &
    ITYMAT,NGRPG,ISDOM,NDOMN,NCHUIG,MXCH,MXUI,NCHG, &
    NDEFCH,NCHGEX,NCHGIN,IDOMG,NCHEXT, &
    NCHINT,NDDLOC,N0DDL,NSDOM,NELTSF,nptctg,nodlc
    COMMON /MAIL/   NODTOT,NELTOT,MXNDEL,NCHTOT,NELDIM,NGRP,NCH, &
    NPTCTR,NCHBEM,NCHUI,NCHSUI,NELEM,NCHTG,NCHBEG, &
    ITYMAT,NGRPG,ISDOM,NDOMN,NCHUIG,MXCH,MXUI,NCHG, &
    NDEFCH,NCHGEX,NCHGIN,IDOMG,NCHEXT, &
    NCHINT,NDDLOC,N0DDL,NSDOM,NELTSF,nptctg,nodlc

    character*80 ::    flchp
    logical ::         lflchp
    common /fchplm/ flchp,lflchp

    INCLUDE '../common/mode.h'
    INCLUDE '../common/integ.h'
