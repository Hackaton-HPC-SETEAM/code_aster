!LATEXBEGIN
!LATEX      parametres sur les analyse statistiques de parametres
!LATEX      calcul du min, max, valeur moyenne et ecart a la moyenne
!LATEXEND
    INTEGER*8 :: mxstpar,iminp,imaxp,imeanp,istdp
    parameter (mxstpar=4)
    parameter (iminp=1)
    parameter (imaxp=2)
    parameter (imeanp=3)
    parameter (istdp=3)
    REAL*8 :: absmin,absmax
    parameter (absmin=-1.e32)
    parameter (absmax=1.e32)
