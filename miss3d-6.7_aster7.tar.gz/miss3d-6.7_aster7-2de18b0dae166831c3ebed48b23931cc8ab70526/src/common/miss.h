!M  COMMON MISSGE
!LATEXBEGIN
!LATEX variables g�n�riques du programme
!LATEX\begin{itemize}
!LATEX \item \label{VERSN} VERSN :  CH80    r�vision courante       CST
!LATEX \item \label{GENER} GENER :  CH80    nom g�n�rique de l'application,
!LATEX \item \label{GEN2M} GEN2M :  CH80    nom g�n�rique des fichiers DOS2M,
!LATEX \item \label{GENTMP} GENTMP :  CH80    nom g�n�rique des fichiers temporaires,
!LATEX \item \label{NREV} NREV :  INTEGER*8 num�ro de r�vision*100,
!LATEX \item \label{NREVF} NREVF :  INTEGER*8 num�ro de r�vision des r�sultats relus,
!LATEX \item \label{MYID} MYID :  num�ro du process courant (MPI),
!LATEX\end{itemize}
!LATEXEND

! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC

    INTEGER*8 :: NREV,NREVF,MYID,numprocs
    CHARACTER*80 ::  VERSN,GENER,GEN2M,GENTMP
    COMMON /MISSGE/ VERSN,GENER,GEN2M,GENTMP,NREV,NREVF,MYID,numprocs


!      COMMON TITLE Titres du probleme
!      -------------------------------

!LATEXBEGIN
!LATEX\begin{itemize}
!LATEX \item \label{TITRE} TITRE :  titre du probl\`eme MISS,
!LATEX \item \label{TRDOS} TRDOS :  titre du probl\`eme DOS2M,
!LATEX \item \label{STRDOS} STRDOS : sous-titre du probl\`eme DOS2M,
!LATEX\end{itemize}
!LATEXEND

    CHARACTER*80 :: TITRE,TRDOS,STRDOS
    COMMON /TITLE/  TITRE,TRDOS,STRDOS


