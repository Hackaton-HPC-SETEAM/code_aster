!M  COMMON AMTH
!LATEXBEGIN
!LATEX pointeurs pour biblioth�ques math�matiques
!LATEX\begin{itemize}
!LATEX \item \label{PTRVR} PTRVR :  adresse d�n tableau de travail
!LATEX\end{itemize}
!LATEXEND

    INTEGER*8 :: PTRVR
    COMMON /AMTH/ PTRVR
