    INTEGER*8 :: nmot
    PARAMETER (NMOT= 20 )
    CHARACTER*4 :: MOT(NMOT)
    DATA MOT /'FREQ','TUDM','UI  ','EOF ','REEL','IMAG','MODU', &
    'PHAS','LEGE','RD/S','MODE','DEPL','VITE','ACCE', &
    'CHAR','MPRP','FORC','DDL ','GNUP','TRIA'/

