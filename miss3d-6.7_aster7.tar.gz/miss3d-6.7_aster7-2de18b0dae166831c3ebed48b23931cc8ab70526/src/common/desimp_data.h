    INTEGER*8 :: nmot
    PARAMETER (NMOT= 16 )
    CHARACTER*4 :: MOT(NMOT)
    DATA MOT /'FREQ','CHPU','CHPT','EOF ','REEL','IMAG','MODU', &
    'PHAS','LEGE','RD/S','MODE','DEPL','VITE','ACCE', &
    'GNUP','TRIA'/

