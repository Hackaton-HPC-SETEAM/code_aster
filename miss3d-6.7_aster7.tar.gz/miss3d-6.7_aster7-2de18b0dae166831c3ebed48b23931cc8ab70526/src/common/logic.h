!M  COMMON LOGIC
!LATEXBEGIN
!LATEX variables logiques definissant les differents choix
!LATEX                d execution
!LATEX\begin{itemize}
!LATEX \item \label{LHOMO} LHOMO :  LOGICAL resolution en espace homogene ( MAIN )
!LATEX ( fonction de Green analytiques )
!LATEX \item \label{LSTRA} LSTRA :  LOGICAL resolution en espace strtifie ( MAIN )
!LATEX ( fonction de Green numerique interpolees sur
!LATEX                        la grille DOS2M, lecture sur les fichiers STO )
!LATEX \item \label{LSURF} LSURF :  LOGICAL maillage de surface sur un sol stratifie (INIDOS)
!LATEX ( LSURF) => ( LSTRA )
!LATEX \item \label{LUD0} LUD0 :  LOGICAL calcul du champs UD0 a partir du champ UI ( MAIN )
!LATEX \item \label{LNEGF} LNEGF :  LOGICAL difference entre points de gauss fins et points
!LATEX                              de gauss grossiers ( RESOU CONTR RESUI ..)
!LATEX \item \label{LCTR} LCTR :  LOGICAL presence de points de controle ( INPUT )
!LATEX \item \label{MODUL} MODUL :  INTEGER*8 POINTE VERS LE MODULE COURANT
!LATEX \item \label{LREWDO} LREWDO :  INTEGER*8 0 pour rembobiner les fichiers dos2m
!LATEX                    ( boucle sur les frequences),
!LATEX                   1 non rembobine
!LATEX \item \label{LPERY} LPERY :  Logical calcul en periodique (suivant y)
!LATEX \item \label{LPERX} LPERX :  Logical calcul en periodique (suivant x)
!LATEX \item \label{LSLOW} LSLOW :  Logical slownesses instead of wavenumbers
!LATEX \item \label{LREGU} LREGU :  Logical r�gularisation
!LATEX \item \label{LREGUE} LREGUE :  Logical r�gularisation domaine ext�rieur
!LATEX \item \label{LREGUI} LREGUI :  Logical r�gularisation domaine int�rieur
!LATEX \item \label{LREGDO} LREGDO :  Logical r�gularisation stratifi�
!LATEX \item \label{LREGUD} LREGUD :  Logical r�gularisation demi-espace
!LATEX \item \label{LAXI} LAXI :  Logical axisym�trie
!LATEX \item \label{L25D} L25D :  Logical 2D g�om�trique, 3D chargements
!LATEX \item \label{L2D} L2D :  Logical 2D
!LATEX \item \label{L3D} L3D :  Logical 3D
!LATEX \item \label{LPSV} LPSV :  Logical Ondes P-SV : Dans le plan
!LATEX \item \label{LSH} LSH :  Logical Ondes SH : Anti-plan
!LATEX \item \label{LMSRC} LMSRC :  Logical Source mobile (2.5D)
!LATEX \item \label{LVIS} LVIS :  Logical Mat�riaux visqueux (DOSLIB)
!LATEX \item \label{LSIG} LSIG :  Logical Calcul des contraintes (DOSLIB)
!LATEX \item \label{LSKMN} LSKMN :  Logical Stockage sur disque des matrices M et N (DOSLIB)
!LATEX \item \label{LSKCF} LSKCF :  Logical Stockage sur disque des matrices CF (DOSLIB)
!LATEX \item \label{LREPRE} LREPRE :  Logical Fct. de Green pour la
!LATEX                                Representation integrale (DOSLIB:AXI)
!LATEX \item \label{LBLFR} LBLFR :  Logical Boucle sur les fr�quences
!LATEX \item \label{LGEOM} LGEOM :  Logical calcul INGEOM
!LATEX \item \label{LNOINI} LNOINI :  Logical pas d'�criture d'entete des fichiers binaires
!LATEX \item \label{LCHTOT} LCHTOT :  Equations Int�grales en champ total
!LATEX \item \label{LFIC} LFIC :  Logical on the fictitious eigenfrequency problem
!LATEX \item \label{LFSNRP} LFSNRP :  Logical on no reciprocity theorem for force assembling
!LATEX \item \label{LCHEX} LCHEX :  Logical on saving the total field at controle points for exterior DOF on a specific file
!LATEX \item \label{LCHIN} LCHIN :  Logical on saving the total field at controle points for interior loads on a specific file
!LATEX\end{itemize}
!LATEXEND
! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC

    LOGICAL :: LHOMO,LSTRA,LSURF,LUD0,LNEGF,LCTR, &
    ldoswv,lgeom,lblfr,lnoini
    LOGICAL ::      LREGU,lregui,lregue,lregud,lregdo, &
    laxi,L25D,lsh,LPSV,L2D,lslow, &
    L3D,LVIS,LSIG,LSKMN,LSKCF,lrepre
    logical :: lmsrc
    logical :: lchtot
    logical :: lpery,lperx
! ullp21-03-02
    logical :: lfic,lfsnrp,lchex,lchin,lrmiss
! ullp02-05-02

    INTEGER*8 ::      MODUL,modaxi,lrewdo
    COMMON /LOGIC/  MODUL,modaxi,lrewdo, &
    LHOMO,LSTRA,LSURF,LUD0,LNEGF,LCTR, &
    ldoswv,LREGU,lgeom,lregui, &
    lregue,lregud,lblfr,lregdo, &
    laxi,L25D,lmsrc,lsh,LPSV,L2D, &
    L3D,LVIS,LSIG,LSKMN,LSKCF,lchtot, &
    lrepre,lnoini,lpery,lperx,lslow,lfic,lfsnrp, &
    lchex,lchin,lrmiss


