!M  COMMON SPEC
!LATEXBEGIN
!LATEX param�tres du domaine spectral DOS2M
!LATEX\begin{itemize}
!LATEX \item \label{NDS} NDS : Nombre de nombres d'onde �chantillonn�s,
!LATEX \item \label{NKS} NKS : taille prescrite des paquets de nombres d'onde,
!LATEX \item \label{NNKS} NNKS : taille r�lle des paquets de nombres d'onde,
!LATEX \item \label{DPAR} DPAR : pas en "lenteur" (COMPLEX),
!LATEX \item \label{DKS}  : obsol�te, cf. DKSI (COMPLEX),
!LATEX \item \label{ID}  : Indice courant,
!LATEX \item \label{DPAR0}  : pas originel en nombre d'onde (REAL)
!LATEX \item \label{DPARI}  : partir imaginaire du pas  en nombre d'onde (REAL)
!LATEX\end{itemize}
!LATEXEND
!
      INTEGER*8   NDS,NKS,NNKS,ID
      REAL*8 DKS,DPAR0,DPARI
      COMPLEX*16 DPAR
      COMMON /SPEC/   DPAR0,NDS,NKS,NNKS,DPAR,DKS,ID,DPARI
