!M  COMMON FICH
!LATEXBEGIN
!LATEX Fichiers associ�s au calcul DOS2M
!LATEX\begin{itemize}
!LATEX \item \label{FLSPEC}  : nom des fichiers du domaine spectral,
!LATEX \item \label{FLFREQ}  :  nom des fichiers du domaine de fr�quences.
!LATEX\end{itemize}
!LATEXEND
!
                      CHARACTER*60 FLSPEC,FLFREQ,FLTIME
                      CHARACTER*60 FLDEPL,FLVITS,FLACCL
      COMMON /FICH/   FLSPEC,FLFREQ,FLTIME,FLDEPL,FLVITS,FLACCL
