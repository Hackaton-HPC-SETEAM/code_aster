!M  COMMON APRUI
!LATEXBEGIN
!LATEX variables pour preparer l integration des fonctions de Green
!LATEX\begin{itemize}
!LATEX \item \label{PORDUI} PORDUI :  Ordre des point source suivant la verticale
!LATEX \item \label{PNPUI} PNPUI :  nombre de points de gauss grossiers entre deux niveaux sources successif
!LATEX \item \label{PWZSUI} PWZSUI :  coefficients d'interpolation par rapport a la verticale
!LATEX \item \label{PZRCWV} PZRCWV :  tableau DOSWV (non implante)
!LATEX\end{itemize}
!LATEXEND

    INTEGER*8 ::     PORDUI,PNPUI ,PWZSUI,PZRCWV
    COMMON /APRPUI/ PORDUI,PNPUI ,PWZSUI,PZRCWV

