!M  DATA DATA
!LATEXBEGIN
!LATEX constantes
!LATEX\begin{itemize}
!LATEX \item \label{CI} CI :  (0.,1.) complexe
!LATEX \item \label{CUN} CUN :  (1.,0.) complexe
!LATEX \item  UN :  1. reel
!LATEX \item \label{CZERO} CZERO :  (0.,0.) complexe
!LATEX \item \label{ZERO} ZERO :  0. reel
!LATEX \item \label{PI} PI :  $\pi$
!LATEX \item \label{PI2} PI2 :  $2\pi$
!LATEX\end{itemize}
!LATEXEND

    REAL*8 ::        UN,ZERO,PI,PI2,DUN,DZERO,NAN
    COMPLEX*16    CZERO,CUN,CI,cdemi

    DATA CI      /(0.,1.)/
    DATA CUN     /(1.,0.)/
    DATA CDEMI   /(.5,0.)/
    DATA UN      /1./
    DATA DUN     /1./
    DATA CZERO   /(0.,0.)/
    DATA ZERO    /0./
    DATA DZERO    /0./
    DATA PI      /3.141592653589793238/
    DATA PI2     /6.283185307179586476/
    DATA NAN     /1E32/

