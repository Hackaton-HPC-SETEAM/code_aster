!*************************************************************
!LATEXBEGIN
!LATEX               Tableaux pour le calcul des fonctions de Bessel
!LATEX               en simple precision.
!LATEXEND
    PARAMETER(nmax=0)
!*************************************************************
    PARAMETER(NMAXP1=NMAX+1 )
    PARAMETER(NB=5)
    PARAMETER(NBORNE=NMAXP1+NB)
    PARAMETER(MAX40 =NMAXP1+7)
    COMMON/BES1/ TABL1(0:NMAXP1,0:NMAXP1),TABL2(0:NMAXP1,0:NB), &
    TABL3(0:NMAXP1,0:NB),TABL8 (0:NMAXP1,7),signe(0:max40)
