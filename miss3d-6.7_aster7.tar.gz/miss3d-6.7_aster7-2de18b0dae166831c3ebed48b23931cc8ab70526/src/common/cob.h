    INTEGER*8 :: nmxcoq
    parameter (nmxcoq=100)
    character*80 :: ficcob
    INTEGER*8 :: itcoq,ntcoq,NNCQ,NELCQ,ndlcq
    logical :: lifss,lcoqef,lcobef,linst,lmpgs,lmovie,lgnu
    common /cob/ ficcob,itcoq(nmxcoq),NNCQ,NELCQ,ntcoq,ndlcq, &
    lifss,lcoqef,lcobef,linst,lmpgs,lmovie,lgnu
