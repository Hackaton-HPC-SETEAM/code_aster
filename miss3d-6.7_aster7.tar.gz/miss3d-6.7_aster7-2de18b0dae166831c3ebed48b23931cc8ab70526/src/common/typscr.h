    INTEGER*8 :: iexpa,ivert,iexpl,ihori,iplaw
    parameter (iexpa=-2)
    parameter (ivert=-3)
    parameter (iexpl=-1)
    parameter (ihori=0)
    parameter (iplaw=-4)
