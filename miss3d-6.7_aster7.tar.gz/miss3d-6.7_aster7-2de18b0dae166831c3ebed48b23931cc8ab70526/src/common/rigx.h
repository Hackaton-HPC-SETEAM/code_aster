    COMPLEX*16 crigix,csoupx,zimp
    COMMON /rigix/ crigix,csoupx,zimp
