! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
!LATEXBEGIN
!LATEX\begin{itemize}
!LATEX \item \label{NBMOD} NBMOD :   INTEGER*8 nombre de modes traites ( fourier, symetries)
!LATEX \item \label{NBMG} NBMG :   INTEGER*8 nombre de modes geometriques ( fourier, symetries)
!LATEX \item \label{NSMOD} NSMOD :   INTEGER*8 nombre de cellules sur lesquelles il y a sommation
!LATEX           espace physique (y)
!LATEX \item \label{ISMOD} ISMOD :   INTEGER*8 compteur sur nsmod (ismod = 1-->nbmod)
!LATEX\end{itemize}
!LATEXEND

! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC

! MLElHabre, 23/04/98 : ajout de nsmod et ismod

    INTEGER*8 ::   nbmod,imod,nbmdg,nsmod,ismod,nsmod2,ismod2

    COMMON /MODE/ nbmod,imod,nbmdg,nsmod,ismod,nsmod2,ismod2
