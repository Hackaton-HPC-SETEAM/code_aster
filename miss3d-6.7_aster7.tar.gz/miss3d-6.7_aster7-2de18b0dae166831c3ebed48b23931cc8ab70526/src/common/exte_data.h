
!     Mot-cles du menu EXTE

    INTEGER*8 :: ncle
    PARAMETER (NCLE=24)
    CHARACTER*4 :: MOT(NCLE)
    DATA MOT /'GROU','LIRE','MASS','KEXT','FINE','MIMF','MSMF','ISS ' &
    ,'EOF','CONT','RIGI','FORC','IFSS','COQR','COQD','COQF', &
    'COBR','COBF','POUT','CRAI','POUM','XFEM','KARH','MODN'/

