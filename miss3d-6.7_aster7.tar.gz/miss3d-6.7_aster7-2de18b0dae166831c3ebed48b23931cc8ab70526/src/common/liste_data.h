    INTEGER*8 :: ncle
    PARAMETER (NCLE=4)
    CHARACTER*4 ::  MOTCLE,MOT(NCLE)
    DATA MOT /'DE  ','/   ','*   ','FIN '/
