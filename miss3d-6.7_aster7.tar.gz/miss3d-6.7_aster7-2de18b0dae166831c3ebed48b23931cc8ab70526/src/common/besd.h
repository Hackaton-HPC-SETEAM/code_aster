!*************************************************************
!LATEXBEGIN
!LATEX               Tableaux pour le calcul des fonctions de Bessel
!LATEX               en double precision.
!LATEXEND
    INTEGER*8 :: nmax,nmaxp1,nb,nborne,max40
    REAL*8 :: tabl1,tabl2,tabl3,tabl8,signe
    PARAMETER(nmax=0)
!*************************************************************
    PARAMETER(NMAXP1=NMAX+1 )
    PARAMETER(NB=30)
    PARAMETER(NBORNE=NMAXP1+NB)
    PARAMETER(MAX40 =NMAXP1+40)
    COMMON/BES1d/ TABL1(0:NMAXP1,0:NMAXP1),TABL2(0:NMAXP1,0:NB), &
    TABL3(0:NMAXP1,0:NB),TABL8 (0:NMAXP1,40),signe(0:max40)
