    character*50 :: comvers(0:nvermx)
    data comvers / &
    ' STANDART SP', &
    ' CRAY NATIVE DP', &
    ' SGI/IRIX -i8 -r8', &
    ' IBM/AIX -dbl ', &
    ' COMPAQ', &
    ' MACOSX/ABSOFT DP', &
    ' LINUX+IFORT+MKL', &    
!C     * ' LINUX+G77+ATLAS DP',
    'MACOS 10.4.9, ifort+MKL 9.1, 2.33GHz intelCoreDuo', &
!    ' MACOSX/ABSOFT SP', &
    ' LINUX+G77+ATLAS SP', &
    ' STANDART SP', &
    ' MACOSX+G77+ATLAS DP', &
    ' MACOSX-G4(1.5GHz) XLF+ATLAS+FFTIMSL', &
    ' ALTIX 16xItanium2 1.5GHz+IFORT+DP+OPENMP', &
    ' BULL Itanium2 1.6GHz+IFORT+MKL', &
    ' LINUX+IFORT+MKL' &
    /

