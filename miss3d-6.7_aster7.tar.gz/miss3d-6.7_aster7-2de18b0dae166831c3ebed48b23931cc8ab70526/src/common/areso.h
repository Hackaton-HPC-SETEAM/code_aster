!M  COMMON ADRESO
!LATEXBEGIN
!LATEX Variables pour l'assemblage et la resolution du systeme equation integrale :
!LATEX            \( T^{g} u = U^{g} T \)
!LATEX avec affectation des conditions aux limites.
!LATEX Les resultats sont stockes sur le fichier ITDM.
!LATEX\begin{itemize}
!LATEX \item \label{PUGEF} PUGEF :  matrice $U^{g}$,
!LATEX \item \label{PTGEF} PTGEF :  matrice $T^{g}$,
!LATEX \item \label{PUGKRS} PUGKRS :  tableau de travail pour lire les fonctions de Green tabulees,
!LATEX \item \label{PUGKEF} PUGKEF :  tableau de travail des fonctions de green avant integration,
!LATEX \item \label{PTGKEF} PTGKEF :  tableau de travail des fonctions de green avant integration,
!LATEX \item \label{PTG0} PTG0 :  noyaux des fonctions de green statique ( Cas regularise),
!LATEX \item \label{PS2M} PS2M :  seconds membres du systeme lineaire,
!LATEX \item \label{PS2MUI} PS2MUI :  seconds membres du systeme lineaire pour les champs $u_{i}$,
!LATEX \item \label{PS2MBE} PS2MBE :  seconds membres du systeme lineaire pour les champs BEM imposes,
!LATEX \item \label{PS1M} PS1M :  matrice du systeme lineaire,
!LATEX \item \label{PSOL} PSOL :  solution du systeme (contient les champs $t(u_{dm})$ et $t(u_{do})$),
!LATEX \item \label{PTD0} PTD0 :  champs diffractes $t(u_{do})$ ,
!LATEX \item \label{PTDBE} PTDBE :  champs diffractes $t(u_{dm})$ pour les champs BEM imposes,
!LATEX \item \label{PIMPDC} PIMPDC :  matrice d impedance,
!LATEX \item \label{PFSEQ} PFSEQ :  force sismique equivalente,
!LATEX \item \label{PIMPBE} PIMPBE :  impedance champs BEM,
!LATEX \item \label{PFSBE} PFSBE :  force sismique equivalente champs BEM,
!LATEX \item \label{PPHLME} PPHLME :  phase sur les champs impos�s
!LATEX \item \label{PDUAUX} PDUAUX :champs duaux sur interfaces surfaciques et volumiques
!LATEX\end{itemize}
!LATEXEND

    INTEGER*8 :: PUGEF ,PTGEF ,PUGKRS,PUGKEF,PTGKEF,PTG0  ,PS2M  , &
    PS2MUI,PS2MBE,PS1M  ,PSOL  ,PTD0  ,PTDBE ,PIMPDC, &
    PFSEQ ,PIMPBE,PTINFUG,PTINFTG,PDUAUX,PPHLME
    COMMON /ARESO/  PUGEF ,PTGEF ,PUGKRS,PUGKEF,PTGKEF,PTG0  ,PS2M  , &
    PS2MUI,PS2MBE,PS1M  ,PSOL  ,PTD0  ,PTDBE ,PIMPDC, &
    PFSEQ ,PIMPBE,PTINFUG,PTINFTG,PDUAUX,PPHLME


