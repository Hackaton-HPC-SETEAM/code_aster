    INTEGER*8 :: nmot
    PARAMETER (NMOT= 23 )
    CHARACTER*4 :: MOT(NMOT)
    DATA MOT /'CHAM','FREQ','NOEU','ELEM','POIN','DDL ','EOF ', &
    'REEL','IMAG','MODU','LEGE','DEPL','VITE','ACCE', &
    'PHAS','MPGS','MODE','COQE','COBE','RELA','INST', &
    'MOVI','GNUP'/
