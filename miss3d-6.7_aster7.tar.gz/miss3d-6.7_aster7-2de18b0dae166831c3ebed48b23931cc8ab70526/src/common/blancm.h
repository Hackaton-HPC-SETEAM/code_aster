!LATEXBEGIN                                                                       
!LATEX   \label{BLANC} : common memoire (programme principal)                                                                       
!LATEXEND                                                                       
      INTEGER*8 mtt                                                                       
      PARAMETER (MTT=200000000)
! mettre un #ifdef 64 bits ou allocation dynamique
!      PARAMETER (MTT=500000000)
      INTEGER*8 IA                                                                       
      COMMON IA(MTT)                                                                       
