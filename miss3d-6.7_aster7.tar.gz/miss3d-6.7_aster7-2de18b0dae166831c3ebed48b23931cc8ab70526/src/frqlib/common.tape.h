!     COMMON TAPE unites fortran des fichiers
!     ----------------------------------------

!         ISCRE: ecran
!         IIN  : fichier de donnees principal ASCII
!         IOUT : fichier de sortie ( messages ) ASCII
!         IUI  : champs incident BINAIRE
!         ILM  : champs imposes BINAIRE
!         ITDM : champs diffractes BINAIRE
!         IUG  : matrice UG BINAIRE
!         ITG  : matrice TG BINAIRE
!         IIMPD: matrice dimpedance
!         IFS  : force sismique equivalente
!         ICTR : champ aux points de controle
!         IAUX : fichier auxiliaire
!         IGEOM: donnees geometriques
!         iprp : points d integration
!         ITUI : champ incident (contraintes)
!         IKGEN: impedance generalisee
!        IFSGEN: force simique generalisee


!     COMMON FTAPE donnees sur les fichiers
!     -------------------------------------

!         RFILE(50) type et nom des fichiers


! CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
    INTEGER*8 ::  ISCRE,IIN,IOUT,IUI,ILM,ITDM,IUG,ITG,IIMPD,IFS, &
    ICTR,IAUX,IGEOM,iprp,ITUI,IKGEN,IFSGEN,ID0,IDES, &
    IMVFD,ikext,IKAUX,iutot,ittot,ictot,imail,icui, &
    iina,ifpfrq
    COMMON /TAPE/  ISCRE,IIN,IOUT,IUI,ILM,ITDM,IUG,ITG,IIMPD,IFS, &
    ICTR,IAUX,IGEOM,iprp,ITUI,IKGEN,IFSGEN,ID0,IDES, &
    IMVFD,ikext,IKAUX,iutot,ittot,ictot,imail,icui, &
    iina,ifpfrq
    CHARACTER(80) :: RFILE(50)
    INTEGER*8 ::      IFTYP(50)
    COMMON /FTAPE/  RFILE,IFTYP
    INTEGER*8 ::       LREC(50)
    COMMON /DAREC/  LREC
    INTEGER*8 ::       LKEY(50)
    COMMON /FLKEY/  LKEY
    INTEGER*8 ::       Lrewfl(50),IFRQF(50),irlast(50),nsfrq(50)
    COMMON /FLRW/  Lrewfl,IFRQF,irlast,nsfrq
